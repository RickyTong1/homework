import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		ArrList list = new ArrList(10);
		Scanner scanner = new Scanner(System.in);
		String str = scanner.nextLine();
		char ch[] = str.toCharArray();
		for(int i=0;i<ch.length;i++) {
			list.add(ch[i]);
		}
		for(int i=0;i<list.current;i++) {
			Object temp = list.data[i];
			for(int j=i+1;j<list.current;j++) {
				if(temp == list.data[j]) {
					list.remove(j);
				}
			}
		}
		list.printElem();
	}
}