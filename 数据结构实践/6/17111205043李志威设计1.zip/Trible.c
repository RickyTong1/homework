#include"common.h"
#include"Trible.h"
Statue InitTGroup (TGroup *L){
	/* �������������һ���յ�˳�����Ա� */
   (*L).elem=(Trible*)malloc(LIST_INIT_SIZE*sizeof(Trible));
  
   if(!(*L).elem)
     exit(OVERFLOW); /* �洢����ʧ�� */
   (*L).length=0; /* �ձ�����Ϊ0 */
   
    (*L).con=0;
	(*L).row =0;
      
  
   return OK;

}
Statue GreatTGroup(TGroup *t,int row,int con){
	int i ,j , m ,count =0;
	Trible *q ;
	Trible b;
	(*t).con = con;
	(*t).row = row;
	q = (*t).elem;
	srand(time(NULL));
	for(i=1;i<=con;i++){
		for(j=1;j<=row;j++){
		   
	       m =  rand()%3;
		   if(m!=0){
			   b.e  =m;
			   b.i = i;
			   b.j = j ;
			   *(q+count) = b ;
			   count++;
			   //q++;
			   (*t).length++;
            }
		}
	}

	
  return OK ;
}
void printfTGroup(TGroup t){
	int i , j,m=0 ;
	Trible *q ;
	Trible b ;
	q = t.elem ;
	
	
	for(i=1;i<=t.con;i++)
	{
		 
		for(j=1;j<=t.row;j++){
			b = *q ;
			if(b.i==i&&b.j==j){
				printf("%.2d   ",b.e);
				q++;
			   
			}
			else 
				printf("00   ");
			

		}
		printf("\n");

	}
}
Statue Transpose(TGroup t ,TGroup *g){
	Trible *p ,*q ;
	int i ;
	Trible a  ;
	p =(*g).elem;
	q =t.elem;
	
	(*g).length = t.length;
	(*g).con = t.row ;
	(*g).row = t.con ;
	for(i=0;i<t.length;i++){
		 a.i = (*q).j;
		 a.j = (*q).i;
		 a.e =(*q).e;
         *(p+i) = a ;
		 q++;
	}
   return OK ;
}

Statue change(TGroup t ,TGroup *g){
	Trible *p ,*q ;
	int i ;
	Trible a  ;
	p =(*g).elem;
	q =t.elem;
	
	(*g).length = t.length;
	(*g).con = t.con ;
	(*g).row = t.row ;
	i = 1;
	for(i=1;i<=t.row;i++){
		q = t.elem;
		for(q;q<=t.elem+t.length;q++){
			a = *q;
			if(a.j==i){
				
				*p = a ;
				p++;
			}
			
		}
		
	}
   return OK ;
}
void printElement(TGroup t){
	int i ;
    Trible *p ;
	p = t.elem;

	for(i=0;i<t.length;i++){

		printf("Ԫ�أ�%d   �У� %d   �У� %d\n",(*p).e,(*p).i,(*p).j);
		p++;
	}
}

